<template>
    <div class="note-count">
        Note count: <strong>{{ noteCount }}</strong>
    </div>
</template>

<script>
export default {
    name: "NoteCount",
	data() {
		return {
			noteCount: 0
		}
	}
};
</script>