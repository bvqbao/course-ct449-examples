<template>
	<div id="products" class="box">
		<div class="products--header has-text-centered">
			<i class="fa fa-2x fa-user-circle"></i>
		</div>
		<div class="product-list">
			<div
				v-for="productItem in productItems"
				:key="productItem.id"
				class="product-list--item"
			>
				<ProductListItem :productItem="productItem" />
			</div>
		</div>
		<div class="product-count has-text-right">
			<span class="has-text-weight-bold"
				># of products: {{ productItems.length }}</span
			>
		</div>
	</div>
</template>

<script>
import ProductListItem from "./ProductListItem.vue";

export default {
	name: "ProductList",
	data() {
		return {
			productItems: [
				{
					id: 1,
					title: "The Fullstack Hoodie",
					description:
						"Lightweight, breathable hoodie with the Fullstack Crest. Guaranteed to keep you looking fresh while warm.",
					price: 19.99,
				},
				{
					id: 2,
					title: "The Fullstack Tee",
					description:
						"The original Fullstack clothing item. Always prepared to keep your style in check.",
					price: 15.99,
				},
				{
					id: 3,
					title: "The Fullstack Fitted Cap",
					description:
						"Stay comfortable and cool with the first Fullstack Fitted Cap, featuring a normal bill and medium crown.",
					price: 15.99,
				},
				{
					id: 4,
					title: "The Fullstack Jacket",
					description:
						"Keep warm and protected with the rugged, durable Fullstack lightweight jacket.",
					price: 49.99,
				},
			],
		};
	},
	components: {
		ProductListItem,
	},
};
</script>

<style scoped>
.tag {
	cursor: pointer;
}

.products--header {
	border-bottom: 1px solid #e8e8e8;
	padding-bottom: 15px;
}

.product-list {
	padding-top: 10px;
}

.product-list--item {
	padding: 10px 0;
}
</style>
