<template>
	<input
		placeholder="Enter a note"
		v-model="input"
		class="input is-small"
		type="text"
	/>
</template>

<script>
export default {
	name: "NoteInput",
	data() {
		return {
			input: "",
		};
	},
};
</script>
